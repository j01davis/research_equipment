# Machine & Product Catalogue

**Open [`index.html`](index.html) in any browser.** Fully offline — copy this folder anywhere and
every page, image and document works with no network connection. 1.3 MB total.

## What is here

**Machine catalogs** — company · standard · cost

| # | Item | Spec | Headline cost |
|---|---|---|---|
| 01 | Automatic powder vacuum packing machine | 0.5–5.0 kg/bag | **$58,000–60,000** full-auto · $4,000–20,000 semi-auto |
| 02 | Batch dry crusher (ore) | Ø100 mm → 0.1–1.0 mm, 50 kg/batch | **$1,500–6,000** hammer mill + **$4,600–30,000** ball mill |

**Products** — product · cost · company · standard

| # | Item | Spec | Headline cost |
|---|---|---|---|
| 03 | Lithium-ion cell | 4.2 V, 1300–2000 mAh | **$1.20–1.50/cell** at MOQ 1,000 |
| 04 | Solar panel array | 3 kW | **$1,110–1,500** wholesale · $3,000–3,300 retail |
| 05 | Hybrid inverter | 24 V, 2–3 kW | **$205–800** (LiTime $419.99) |
| 06 | Solar panel | 20–24 V, 15–20 A | **$159.99–639.99** |

## Three things worth reading before you order

### Item 02 needs two machines, not one
Ø100 mm down to 0.1–1.0 mm is a **100:1 to 1000:1 reduction ratio**. No single dry crusher does that
on ore in one pass. You need a **hammer mill** (the JXSC PC400×200 takes exactly 100 mm feed and
discharges 0.2–6 mm) followed by a **batch ball mill** to reach 0.1–1.0 mm — which is also where your
"50 kg per batch" belongs, since ball mills are inherently batch machines.

### Item 01 is often mis-sold
Most machines advertised as "powder packing machines" are auger fillers that fill to **grams, not
kilos**, and have **no vacuum stage at all**. The machine that genuinely meets 0.5–5 kg with vacuum is
a brick-shape VFFS, and it costs $50,000–65,000. The cheap alternative is a premade-pouch vacuum
packer (~$12,000) where you buy the bags.

### Items 03–06 are one system, and as specified they will not work together
See the **compatibility check** at the foot of `index.html`. Summary:

1. **A 20–24 V panel cannot charge a 24 V battery bank.** Your item 6 spec is a *12 V-nominal*
   panel (a real 24 V panel is Vmp 36–41 V). Wired in parallel to reach 15–20 A it still peaks near
   20 V — below the ~28.8 V needed. Fix: wire panels **in series**, or buy true 24 V panels.
2. **A 3 kW array will not fit a 24 V/3 kW hybrid inverter.** The 3 kW is AC *output*; the MPPT
   **PV input is only 1,600 W** on this class (confirmed on the LiTime unit's own spec plate).
   Your item 4 is nearly double that.
3. **3 kW at 24 V is 125 A DC.** That needs 35–50 mm² (2/0 AWG) cable and a 150–200 A fuse. It also
   means a 18650 pack of roughly **7S20P ≈ 140 cells** for only ~1.0 kWh — about 20 minutes at full
   inverter load.

**Recommendation:** if the goal is a working 3 kW off-grid system, go **48 V**, use **LiFePO₄
prismatic cells** rather than 18650s, and use **24 V-or-higher panels wired in series**. That removes
all three problems. If 24 V is fixed, size the inverter at 2 kW and the array at 1.6 kW.

## Layout

```
research_equipment/
  index.html          start here (includes the compatibility check)
  README.md           this file
  01_powder_vacuum_packing_machine/   catalog.html · img/ · docs/
  02_batch_dry_crusher/
  03_lithium_ion_battery/
  04_solar_panel_3kw/
  05_hybrid_inverter_24v/
  06_solar_panel_20_24v/
```

`*_archived.html` files are vendor web pages captured as clean offline text, including the JXSC
hammer mill model table, the LiTime inverter spec, the Renogy 12 V panel data and the 18650 datasheets.

## Limitations

- **Item 01 full-auto prices are market bands**, not a single vendor quote — brick VFFS machines are
  configured per product and quoted per project.
- **Item 02 has no published prices.** Chinese hammer mills and ball mills in this size are quote-only;
  the figures given are class ranges, with one Western listed price ($26,069.95) as an anchor.
- **Battery cell prices move with lithium carbonate**; treat the $1.20–1.50 figure as a 2026 snapshot.
- **Solar panel pricing is mid-shift** — wholesale is ~$0.37/W now but expected to settle at
  $0.45–0.50/W as new tariffs take effect.
- Product photos are supplier marketing images; some carry vendor watermarks.
